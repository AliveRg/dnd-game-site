<script setup lang="ts">
const cfg = useRuntimeConfig().public
const open = ref(false)
const nav = [
  { to: '/#about', label: 'О клубе' },
  { to: '/#prices', label: 'Цены' },
  { to: '/games', label: 'Сюжеты' },
  { to: '/#booking', label: 'Расписание' },
  { to: '/news', label: 'Новости' }
]

// Микроразметка организации — для Яндекса/Google (адрес и соцсети заполнить, когда дадут)
useHead({
  meta: String(cfg.indexable) === 'true' ? [] : [{ name: 'robots', content: 'noindex, nofollow' }],
  titleTemplate: (t) => (t ? `${t}` : `${cfg.siteName} — клуб настольных ролевых игр D&D`),
  script: [
    {
      type: 'application/ld+json',
      innerHTML: JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'EntertainmentBusiness',
        name: cfg.siteName,
        url: cfg.siteUrl,
        image: `${cfg.siteUrl}/images/og.jpg`,
        description: 'Клуб настольных ролевых игр: D&D 5e, ваншоты и кампании, до 5 игроков за столом.',
        priceRange: '1500–3000 ₽',
        address: { '@type': 'PostalAddress', addressLocality: cfg.city, addressCountry: 'RU' /* streetAddress: 'ул. …' — добавить, когда будет адрес */ }
        // sameAs: ['https://t.me/...', 'https://vk.com/...']
      })
    }
  ]
})
</script>

<template>
  <div class="flex min-h-dvh flex-col">
    <header class="fixed inset-x-0 top-0 z-40 border-b border-wood-2/60 bg-ink/80 backdrop-blur">
      <div class="container-x flex h-16 items-center justify-between">
        <NuxtLink to="/" class="font-display text-xl text-candle">{{ cfg.siteName }}</NuxtLink>
        <nav class="hidden gap-6 text-sm md:flex">
          <NuxtLink v-for="n in nav" :key="n.to" :to="n.to" class="hover:text-candle">{{ n.label }}</NuxtLink>
        </nav>
        <NuxtLink to="/#booking" class="btn-primary hidden py-2 md:inline-flex">Записаться</NuxtLink>
        <button class="md:hidden" aria-label="Меню" @click="open = !open">☰</button>
      </div>
      <nav v-if="open" class="container-x flex flex-col gap-3 pb-4 md:hidden" @click="open = false">
        <NuxtLink v-for="n in nav" :key="n.to" :to="n.to">{{ n.label }}</NuxtLink>
        <NuxtLink to="/#booking" class="btn-primary">Записаться</NuxtLink>
      </nav>
    </header>

    <main class="flex-1 pt-16"><slot /></main>

    <footer class="border-t border-wood-2 py-10 text-sm text-ash">
      <div class="container-x flex flex-col justify-between gap-4 md:flex-row">
        <p>© {{ new Date().getFullYear() }} {{ cfg.siteName }}. Клуб настольных ролевых игр.</p>
        <div class="flex gap-4">
          <NuxtLink to="/privacy" class="hover:text-candle">Политика конфиденциальности</NuxtLink>
          <!-- TODO: ссылки на Telegram / VK -->
        </div>
      </div>
    </footer>
  </div>
</template>
