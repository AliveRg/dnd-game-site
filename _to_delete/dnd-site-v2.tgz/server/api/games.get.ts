import { seedGames } from '../data/games'

export default defineEventHandler(async () => {
  if (!isDbConfigured()) {
    return seedGames.map((g, i) => ({ id: i + 1, type: 'game', slug: g.slug, title: g.title, excerpt: g.excerpt, cover: g.cover ?? null, meta: g.meta }))
  }
  const { rows } = await useDb().query(
    `SELECT id, type, slug, title, excerpt, cover, meta FROM posts WHERE type = 'game' AND published ORDER BY id`
  )
  return rows
})
