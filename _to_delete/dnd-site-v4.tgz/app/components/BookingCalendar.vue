<script setup lang="ts">
import { TARIFFS, MAX_PLAYERS, estimatePrice } from '#shared/utils/pricing'

interface Session {
  id: number
  starts_at: string
  duration_h: string
  max_players: number
  price: number
  is_weekly: boolean
  note: string
  game_slug: string | null
  game_title: string | null
  game_excerpt: string | null
  seats_left: number
}

const { $ymGoal } = useNuxtApp()
const { data: sessions, refresh } = await useFetch<Session[]>('/api/sessions', { default: () => [] })

// --- Календарь: 5 недель вперёд, начиная с понедельника текущей недели ---
const dayKey = (d: Date) => d.toLocaleDateString('sv-SE', { timeZone: 'Europe/Moscow' }) // YYYY-MM-DD
const days = computed(() => {
  const start = new Date()
  start.setHours(0, 0, 0, 0)
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7))
  return Array.from({ length: 35 }, (_, i) => {
    const d = new Date(start)
    d.setDate(start.getDate() + i)
    return d
  })
})
const byDay = computed(() => {
  const m = new Map<string, Session[]>()
  for (const s of sessions.value) {
    const k = dayKey(new Date(s.starts_at))
    m.set(k, [...(m.get(k) ?? []), s])
  }
  return m
})
const todayKey = dayKey(new Date())
const selectedDay = ref<string | null>(null)
const selected = ref<Session | null>(null)
const daySessions = computed(() => (selectedDay.value ? byDay.value.get(selectedDay.value) ?? [] : []))

function pickDay(d: Date) {
  const k = dayKey(d)
  if (!byDay.value.has(k)) return
  selectedDay.value = k
  const list = byDay.value.get(k)!.filter((s) => s.seats_left > 0)
  selected.value = list.length === 1 ? list[0]! : null
}
const fmtTime = (s: string) => new Date(s).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Moscow' })
const fmtDate = (s: string) => new Date(s).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', weekday: 'long', timeZone: 'Europe/Moscow' })

// --- Форма ---
const form = reactive({ name: '', contact: '', players: 1, tariff: 'promo4', invitedBy: '', comment: '', consent: false, website: '' })
const maxSeats = computed(() => (selected.value ? Math.min(selected.value.seats_left, MAX_PLAYERS) : MAX_PLAYERS))
watch(maxSeats, (m) => { if (form.players > m) form.players = Math.max(1, m) })
const price = computed(() => estimatePrice(form.tariff, form.players))

const state = ref<'idle' | 'sending' | 'ok' | 'error'>('idle')
const error = ref('')
async function submit() {
  state.value = 'sending'
  error.value = ''
  try {
    await $fetch('/api/booking', { method: 'POST', body: { ...form, sessionId: selected.value?.id ?? null, utm: getUtm() } })
    state.value = 'ok'
    $ymGoal('booking_sent', { players: form.players, tariff: form.tariff })
    refresh()
  } catch (e: any) {
    state.value = 'error'
    error.value = e?.data?.message || 'Не получилось отправить, попробуйте ещё раз'
  }
}
</script>

<template>
  <div class="grid gap-8 lg:grid-cols-2">
    <!-- Календарь -->
    <div class="card">
      <div class="mb-3 grid grid-cols-7 text-center text-xs text-ash">
        <span v-for="w in ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']" :key="w">{{ w }}</span>
      </div>
      <div class="grid grid-cols-7 gap-1">
        <button
          v-for="d in days"
          :key="d.toISOString()"
          type="button"
          class="relative aspect-square rounded-lg text-sm transition"
          :class="[
            byDay.has(dayKey(d)) ? 'bg-candle/15 text-candle hover:bg-candle/30' : 'text-ash/40 cursor-default',
            selectedDay === dayKey(d) && 'ring-2 ring-candle',
            dayKey(d) === todayKey && 'font-bold underline'
          ]"
          @click="pickDay(d)"
        >
          {{ d.getDate() }}
          <span v-if="byDay.has(dayKey(d))" class="absolute bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-candle" />
        </button>
      </div>

      <div v-if="!sessions.length" class="mt-6 text-sm text-ash">
        Расписание скоро появится. Оставьте заявку — подберём игру и напишем.
      </div>
      <div v-else-if="!selectedDay" class="mt-6 text-sm text-ash">Выберите подсвеченный день.</div>

      <div v-if="daySessions.length" class="mt-6 space-y-3">
        <button
          v-for="s in daySessions"
          :key="s.id"
          type="button"
          class="w-full rounded-xl border p-4 text-left transition"
          :class="selected?.id === s.id ? 'border-candle bg-candle/10' : 'border-wood-2 hover:border-candle/60'"
          :disabled="s.seats_left === 0"
          @click="selected = s"
        >
          <div class="flex items-center justify-between">
            <span class="font-semibold">{{ fmtTime(s.starts_at) }} · {{ s.game_title || 'Партия' }}</span>
            <span v-if="s.is_weekly" class="rounded bg-candle px-2 text-xs text-ink">История недели</span>
          </div>
          <p class="mt-1 text-sm text-ash">{{ Number(s.duration_h) }} ч · {{ s.price }} ₽ · свободно мест: <b :class="s.seats_left ? 'text-candle' : 'text-red-400'">{{ s.seats_left }}</b> из {{ s.max_players }}</p>
        </button>
      </div>
    </div>

    <!-- Форма -->
    <div class="card">
      <template v-if="state !== 'ok'">
        <p class="font-display text-2xl">
          {{ selected ? `${selected.game_title ?? 'Партия'} — ${fmtDate(selected.starts_at)}, ${fmtTime(selected.starts_at)}` : 'Заявка без даты — подберём сами' }}
        </p>
        <form class="mt-5 space-y-4" @submit.prevent="submit">
          <input v-model="form.website" class="hidden" tabindex="-1" autocomplete="off" />
          <div class="grid gap-4 sm:grid-cols-2">
            <div><label class="label">Имя</label><input v-model="form.name" class="input" required /></div>
            <div><label class="label">Telegram / VK / e-mail</label><input v-model="form.contact" class="input" required /></div>
          </div>

          <div>
            <label class="label">Тариф</label>
            <div class="grid gap-2 sm:grid-cols-3">
              <label v-for="t in TARIFFS" :key="t.id" class="cursor-pointer rounded-lg border p-3 text-sm" :class="form.tariff === t.id ? 'border-candle bg-candle/10' : 'border-wood-2'">
                <input v-model="form.tariff" type="radio" :value="t.id" class="hidden" />
                <b>{{ t.price }} ₽</b><br /><span class="text-ash">{{ t.title }}</span>
              </label>
            </div>
          </div>

          <div class="grid gap-4 sm:grid-cols-2">
            <div>
              <label class="label">Сколько мест (вы + друзья)</label>
              <input v-model.number="form.players" type="number" min="1" :max="maxSeats" class="input" />
            </div>
            <div>
              <label class="label">Кто вас пригласил (если есть)</label>
              <input v-model="form.invitedBy" class="input" placeholder="Имя / ник" />
            </div>
          </div>

          <div><label class="label">Комментарий</label><textarea v-model="form.comment" rows="2" class="input" placeholder="Опыт в НРИ, пожелания…" /></div>

          <div class="rounded-lg bg-ink/60 p-4 text-sm">
            Примерно: <b class="text-xl text-candle">{{ price.total.toLocaleString('ru-RU') }} ₽</b> за всю компанию
            <span v-if="price.discount" class="block text-ash">ваша скидка за друзей: −{{ price.discount }} ₽</span>
            <span class="block text-xs text-ash">Точную сумму подтвердит мастер</span>
          </div>

          <label class="flex items-start gap-2 text-xs text-ash">
            <input v-model="form.consent" type="checkbox" required class="mt-0.5" />
            <span>Согласен на обработку персональных данных и с <NuxtLink to="/privacy" class="underline">политикой конфиденциальности</NuxtLink></span>
          </label>

          <p v-if="selected && selected.seats_left === 0" class="text-sm text-red-400">На эту партию мест нет — выберите другую дату или оставьте заявку без даты.</p>
          <button class="btn-primary w-full" :disabled="state === 'sending' || (selected?.seats_left === 0)">{{ state === 'sending' ? 'Отправляем…' : 'Отправить заявку' }}</button>
          <p v-if="error" class="text-sm text-red-400">{{ error }}</p>
        </form>
      </template>
      <div v-else class="py-16 text-center">
        <p class="font-display text-3xl">Место за столом ждёт 🎲</p>
        <p class="mt-2 text-ash">Мы получили заявку и скоро напишем.</p>
      </div>
    </div>
  </div>
</template>
