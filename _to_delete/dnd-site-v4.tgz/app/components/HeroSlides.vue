<script setup lang="ts">
// Фон hero: фото сменяются с плавным зумом. Добавляй фото в массив (лучше webp 1920px, до 250 КБ).
const slides = ['/images/hero-table.webp', '/images/hero-minis.webp']
const i = ref(0)
let t: ReturnType<typeof setInterval> | undefined
onMounted(() => { t = setInterval(() => (i.value = (i.value + 1) % slides.length), 7000) })
onBeforeUnmount(() => clearInterval(t))
</script>

<template>
  <div class="absolute inset-0 overflow-hidden" aria-hidden="true">
    <TransitionGroup enter-active-class="transition-opacity duration-[1500ms]" leave-active-class="transition-opacity duration-[1500ms]" enter-from-class="opacity-0" leave-to-class="opacity-0">
      <img v-for="(src, idx) in slides" v-show="idx === i" :key="src" :src="src" alt="" class="kenburns absolute inset-0 h-full w-full object-cover" :fetchpriority="idx === 0 ? 'high' : 'low'" :loading="idx === 0 ? 'eager' : 'lazy'" decoding="async" />
    </TransitionGroup>
    <div class="absolute inset-0 bg-gradient-to-b from-ink/70 via-ink/60 to-ink" />
  </div>
</template>
