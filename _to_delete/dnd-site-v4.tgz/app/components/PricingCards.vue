<script setup lang="ts">
import { TARIFFS, FRIEND_DISCOUNT, FRIEND_DISCOUNT_CAP, PROMO_UNTIL, REGULAR_PRICE_4H } from '#shared/utils/pricing'
const until = new Date(PROMO_UNTIL).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })
</script>

<template>
  <div>
    <div class="grid gap-6 md:grid-cols-3">
      <div v-for="t in TARIFFS" :key="t.id" class="card relative flex flex-col" :class="t.id === 'promo4' && 'border-candle'">
        <span v-if="'badge' in t" class="absolute -top-3 left-6 rounded-full bg-candle px-3 py-0.5 text-xs font-bold text-ink">{{ t.badge }}</span>
        <p class="font-display text-2xl">{{ t.title }}</p>
        <p class="mt-4 text-4xl font-bold text-candle">{{ t.price.toLocaleString('ru-RU') }} ₽</p>
        <p class="text-sm text-ash">с человека за {{ t.hours }} часа{{ t.hours === 6 ? 'ов' : '' }} игры</p>
        <p v-if="t.id === 'promo4'" class="mt-1 text-xs text-candle">Акция до {{ until }}, далее {{ REGULAR_PRICE_4H }} ₽</p>
        <p class="mt-4 flex-1 text-sm">{{ t.note }}</p>
        <NuxtLink :to="`/#booking`" class="btn-ghost mt-6">Выбрать</NuxtLink>
      </div>
    </div>
    <p class="mt-6 text-center text-ash">
      Приведи друга — <b class="text-candle">−{{ FRIEND_DISCOUNT }} ₽</b> тебе за каждого на 4-часовую партию (скидка до {{ FRIEND_DISCOUNT_CAP * 100 }}%), а друг играет за 1 500 ₽.
    </p>
  </div>
</template>
