<script setup lang="ts">
// Короткая форма на первом экране: имя + контакт → заявка "подобрать партию"
const { $ymGoal } = useNuxtApp()
const form = reactive({ name: '', contact: '', consent: true, website: '' })
const state = ref<'idle' | 'sending' | 'ok' | 'error'>('idle')
const error = ref('')

async function submit() {
  state.value = 'sending'
  error.value = ''
  try {
    await $fetch('/api/booking', { method: 'POST', body: { ...form, players: 1, tariff: 'promo4', comment: 'Заявка с первого экрана', utm: getUtm() } })
    state.value = 'ok'
    $ymGoal('hero_form_sent')
  } catch (e: any) {
    state.value = 'error'
    error.value = e?.data?.message || 'Не получилось отправить'
  }
}
</script>

<template>
  <div class="card w-full max-w-md backdrop-blur">
    <template v-if="state !== 'ok'">
      <p class="mb-1 font-display text-2xl">Записаться на партию</p>
      <p class="mb-4 text-sm text-ash">Напишем и подберём ближайшую игру</p>
      <form class="space-y-3" @submit.prevent="submit">
        <input v-model="form.website" class="hidden" tabindex="-1" autocomplete="off" />
        <input v-model="form.name" class="input" placeholder="Имя" required autocomplete="given-name" />
        <input v-model="form.contact" class="input" placeholder="Telegram, VK или e-mail" required />
        <label class="flex items-start gap-2 text-xs text-ash">
          <input v-model="form.consent" type="checkbox" required class="mt-0.5" />
          <span>Согласен на обработку персональных данных и с <NuxtLink to="/privacy" class="underline">политикой</NuxtLink></span>
        </label>
        <button class="btn-primary w-full" :disabled="state === 'sending'">{{ state === 'sending' ? 'Отправляем…' : 'Хочу играть' }}</button>
        <p v-if="error" class="text-sm text-red-400">{{ error }}</p>
      </form>
    </template>
    <p v-else class="py-6 text-center">Заявка у нас! Скоро напишем 🎲</p>
  </div>
</template>
