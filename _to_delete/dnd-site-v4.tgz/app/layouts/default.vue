<script setup lang="ts">
const cfg = useRuntimeConfig().public
const open = ref(false)
import { LANDINGS, ARTICLES, pagePath, fillCity } from '#shared/seo-pages'
const nav = [
  { to: '/o-klube', label: 'О клубе' },
  { to: '/ceny', label: 'Цены' },
  { to: '/games', label: 'Сюжеты' },
  { to: '/karta', label: 'Карта' },
  { to: '/raspisanie', label: 'Расписание' },
  { to: '/stati', label: 'Статьи' },
  { to: '/news', label: 'Новости' }
]
const short = (s: string) => fillCity(s, cfg.cityIn, cfg.city).replace(/:.*$/, '')

// Микроразметка организации — для Яндекса/Google (адрес и соцсети заполнить, когда дадут)
useHead({
  meta: String(cfg.indexable) === 'true' ? [] : [{ name: 'robots', content: 'noindex, nofollow' }],
  titleTemplate: (t) => (t ? `${t}` : `${cfg.siteName} — клуб настольных ролевых игр D&D`),
  script: [
    {
      type: 'application/ld+json',
      innerHTML: JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'EntertainmentBusiness',
        name: cfg.siteName,
        url: cfg.siteUrl,
        image: `${cfg.siteUrl}/images/og.jpg`,
        description: 'Клуб настольных ролевых игр: D&D 5e, ваншоты и кампании, до 5 игроков за столом.',
        priceRange: '1500–3000 ₽',
        address: { '@type': 'PostalAddress', addressLocality: cfg.city, addressCountry: 'RU' /* streetAddress: 'ул. …' — добавить, когда будет адрес */ }
        // sameAs: ['https://t.me/...', 'https://vk.com/...']
      })
    }
  ]
})
</script>

<template>
  <div class="flex min-h-dvh flex-col">
    <header class="fixed inset-x-0 top-0 z-40 border-b border-wood-2/60 bg-ink/80 backdrop-blur">
      <div class="container-x flex h-16 items-center justify-between">
        <NuxtLink to="/" class="font-display text-xl text-candle">{{ cfg.siteName }}</NuxtLink>
        <nav class="hidden gap-6 text-sm md:flex">
          <NuxtLink v-for="n in nav" :key="n.to" :to="n.to" class="hover:text-candle">{{ n.label }}</NuxtLink>
        </nav>
        <NuxtLink to="/#booking" class="btn-primary hidden py-2 md:inline-flex">Записаться</NuxtLink>
        <button class="md:hidden" aria-label="Меню" @click="open = !open">☰</button>
      </div>
      <nav v-if="open" class="container-x flex flex-col gap-3 pb-4 md:hidden" @click="open = false">
        <NuxtLink v-for="n in nav" :key="n.to" :to="n.to">{{ n.label }}</NuxtLink>
        <NuxtLink to="/#booking" class="btn-primary">Записаться</NuxtLink>
      </nav>
    </header>

    <main class="flex-1 pt-16"><slot /></main>

    <footer class="border-t border-wood-2 py-10 text-sm text-ash">
      <!-- Перелинковка: все SEO-страницы из футера -->
      <div class="container-x mb-8 grid gap-8 sm:grid-cols-3">
        <div>
          <p class="mb-2 font-semibold text-parchment">Играть</p>
          <NuxtLink v-for="p in LANDINGS" :key="p.slug" :to="pagePath(p)" class="block py-0.5 hover:text-candle">{{ short(p.h1) }}</NuxtLink>
        </div>
        <div>
          <p class="mb-2 font-semibold text-parchment">Статьи</p>
          <NuxtLink v-for="p in ARTICLES" :key="p.slug" :to="pagePath(p)" class="block py-0.5 hover:text-candle">{{ short(p.h1) }}</NuxtLink>
        </div>
        <div>
          <p class="mb-2 font-semibold text-parchment">Клуб</p>
          <NuxtLink v-for="n in nav" :key="n.to" :to="n.to" class="block py-0.5 hover:text-candle">{{ n.label }}</NuxtLink>
          <NuxtLink to="/kontakty" class="block py-0.5 hover:text-candle">Контакты</NuxtLink>
        </div>
      </div>
      <div class="container-x flex flex-col justify-between gap-4 md:flex-row">
        <p>© {{ new Date().getFullYear() }} {{ cfg.siteName }}. Клуб настольных ролевых игр.</p>
        <div class="flex gap-4">
          <NuxtLink to="/privacy" class="hover:text-candle">Политика конфиденциальности</NuxtLink>
          <!-- TODO: ссылки на Telegram / VK -->
        </div>
      </div>
    </footer>
  </div>
</template>
