<script setup lang="ts">
const cfg = useRuntimeConfig().public
const city = cfg.cityIn ? ` ${cfg.cityIn}` : ''
useSiteSeo({
  title: `Сюжеты и ваншоты D&D 5e, хоррор и детективы${city} | ${cfg.siteName}`,
  description: 'Все истории клуба: ваншоты, модули и кампании по D&D 5e, Витрувию и другим НРИ. Выбирайте жанр и записывайтесь.'
})
const { data: games } = await useFetch('/api/games', { default: () => [] as any[] })
const filter = ref<'all' | 'Ваншот' | 'Модуль' | 'Кампания'>('all')
const list = computed(() => (filter.value === 'all' ? games.value : games.value.filter((g: any) => g.meta?.kind === filter.value)))
</script>

<template>
  <section class="section">
    <div class="container-x">
      <h1 class="section-title">Сюжеты и миры</h1>
      <div class="mb-8 flex flex-wrap gap-2">
        <button v-for="f in ['all', 'Ваншот', 'Модуль', 'Кампания']" :key="f" class="btn-ghost py-2" :class="filter === f && 'border-candle text-candle'" @click="filter = f as any">
          {{ f === 'all' ? 'Все' : f }}
        </button>
      </div>
      <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <GameCard v-for="g in list" :key="g.slug" :game="g" />
      </div>
    </div>
  </section>
</template>
