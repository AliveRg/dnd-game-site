<script setup lang="ts">
const cfg = useRuntimeConfig().public
useSiteSeo({ title: `Контакты — клуб НРИ ${cfg.cityIn}`, description: `Как нас найти: адрес клуба настольных ролевых игр ${cfg.cityIn}, Telegram, VK.` })
</script>

<template>
  <section class="container-x max-w-3xl py-12">
    <h1 class="text-4xl md:text-5xl">Контакты</h1>
    <!-- TODO: адрес, карта Яндекса (iframe), Telegram, VK, часы работы. Адрес + карта — сильный сигнал для локального SEO -->
    <p class="mt-6 text-ash">{{ cfg.city }}, адрес уточняется.</p>
    <div class="mt-10"><QuickForm /></div>
  </section>
</template>
