<script setup lang="ts">
useSiteSeo({ title: 'Политика конфиденциальности', description: 'Политика обработки персональных данных.' })
useHead({ meta: [{ name: 'robots', content: 'noindex, follow' }] })
</script>

<template>
  <section class="container-x max-w-3xl py-12">
    <h1 class="text-4xl">Политика обработки персональных данных</h1>
    <!-- TODO: заказчику нужен реальный текст политики по 152-ФЗ (оператор, ИНН/ОГРНИП, цели, сроки хранения).
         Также нужно подать уведомление в Роскомнадзор как оператор ПД. -->
    <p class="mt-6 text-ash">Мы собираем имя и контакт (Telegram, VK или e-mail) только для того, чтобы связаться с вами по поводу записи на игру. Данные не передаются третьим лицам.</p>
  </section>
</template>
