<script setup lang="ts">
const cfg = useRuntimeConfig().public
useSiteSeo({ title: `Расписание игр D&D и НРИ ${cfg.cityIn} — запись онлайн`, description: `Ближайшие партии ${cfg.cityIn}: даты, сюжеты, свободные места. До 5 игроков на партию. Запишитесь онлайн.` })
</script>

<template>
  <section class="section">
    <div class="container-x">
      <h1 class="section-title">Расписание и запись</h1>
      <p class="-mt-4 mb-8 text-ash">До 5 человек на партию. Каждую неделю — новая история.</p>
      <BookingCalendar />
    </div>
  </section>
</template>
