import { seedGames } from '../data/games'

// Точки на карте по умолчанию берём из стартовых данных, если в админке их ещё не задали
const defaultMap = (slug: string) => seedGames.find((g) => g.slug === slug)?.meta.map

export default defineEventHandler(async () => {
  if (!isDbConfigured()) {
    return seedGames.map((g, i) => ({ id: i + 1, type: 'game', slug: g.slug, title: g.title, excerpt: g.excerpt, cover: g.cover ?? null, meta: g.meta }))
  }
  const { rows } = await useDb().query(
    `SELECT id, type, slug, title, excerpt, cover, meta FROM posts WHERE type = 'game' AND published ORDER BY id`
  )
  return rows.map((r) => ({ ...r, meta: { ...r.meta, map: r.meta?.map ?? defaultMap(r.slug) } }))
})
