import { seedGames } from '../../data/games'

export default defineEventHandler(async (event) => {
  const slug = getRouterParam(event, 'slug')!
  if (!isDbConfigured()) {
    const g = seedGames.find((x) => x.slug === slug)
    if (!g) throw createError({ statusCode: 404, message: 'Не найдено' })
    return { id: 0, type: 'game', ...g, seo_title: g.seoTitle, seo_description: g.seoDescription }
  }
  const { rows } = await useDb().query(`SELECT * FROM posts WHERE slug = $1 AND published`, [slug])
  if (!rows[0]) throw createError({ statusCode: 404, message: 'Не найдено' })
  return rows[0]
})
