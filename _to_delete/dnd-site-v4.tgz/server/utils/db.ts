import pg from 'pg'
import { TIMEWEB_CA } from './timeweb-ca'

let pool: pg.Pool | null = null

export function useDb(): pg.Pool {
  if (pool) return pool
  const config = useRuntimeConfig()
  if (!config.databaseUrl) {
    throw createError({ statusCode: 503, message: 'База данных не настроена (NUXT_DATABASE_URL)' })
  }
  pool = new pg.Pool({
    connectionString: config.databaseUrl,
    // NUXT_DB_SSL=true → SSL с проверкой сертификата Timeweb (аналог sslmode=verify-full)
    ssl: String(config.dbSsl) === 'true' ? { ca: TIMEWEB_CA, rejectUnauthorized: true } : undefined,
    max: 5,
    idleTimeoutMillis: 30_000
  })
  pool.on('error', (e) => console.error('[db] pool error', e.message))
  return pool
}

export function isDbConfigured() {
  return Boolean(useRuntimeConfig().databaseUrl)
}

export function slugify(input: string) {
  const map: Record<string, string> = {
    а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k',
    л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c',
    ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya'
  }
  return input
    .toLowerCase()
    .split('')
    .map((c) => map[c] ?? c)
    .join('')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80)
}
