<script setup lang="ts">
// «Доверься судьбе»: бросок d20 выбирает сюжет → карта переворачивается с ним → кнопка записи
const { $ymGoal } = useNuxtApp()
const { data: games } = await useFetch<any[]>('/api/games', { default: () => [] })

const dice = ref<{ roll: (n?: number) => Promise<number> }>()
const open = ref(false)
const flipped = ref(false)
const result = ref(0)
const game = ref<any>(null)

async function go() {
  if (!games.value.length || !dice.value) return
  open.value = false
  flipped.value = false
  const r = await dice.value.roll()
  result.value = r
  game.value = games.value[(r - 1) % games.value.length]
  $ymGoal('fate_roll', { result: r, game: game.value?.slug })
  open.value = true
  setTimeout(() => (flipped.value = true), 450)
}
function close() { open.value = false }
onMounted(() => window.addEventListener('keydown', (e) => e.key === 'Escape' && close()))
const verdict = computed(() => (result.value === 20 ? 'Критический успех!' : result.value === 1 ? 'Провал… но судьба даёт шанс' : `Выпало ${result.value}`))
</script>

<template>
  <div class="flex items-center gap-4">
    <Dice3D ref="dice" size="clamp(110px, 22vw, 170px)" label="Бросить кубик судьбы" @click="go" />
    <div>
      <p class="font-display text-2xl text-candle">Доверься судьбе</p>
      <p class="max-w-[16rem] text-sm text-ash">Брось кубик — и он выберет историю для твоей первой партии</p>
    </div>

    <Teleport to="body">
      <Transition enter-active-class="transition duration-300" enter-from-class="opacity-0" leave-active-class="transition duration-200" leave-to-class="opacity-0">
        <div v-if="open && game" class="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-ink/85 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Выбор судьбы" @click.self="close">
          <div class="flex flex-col items-center gap-5 py-8">
            <TarotCard v-model:flipped="flipped" :interactive="false" width="min(320px, 82vw)">
              <p class="text-xs uppercase tracking-[.2em] text-[#8a5a1f]">{{ verdict }}</p>
              <p v-if="game.meta?.series" class="mt-3 text-[11px] uppercase tracking-widest text-[#6b4a24]">{{ game.meta.series }}</p>
              <p class="mt-1 font-display text-[28px] leading-tight">{{ game.title }}</p>
              <div class="mx-auto my-3 h-px w-2/3 bg-[#8a5a1f66]" />
              <p class="text-sm leading-snug">{{ game.excerpt }}</p>
              <div class="mt-auto flex flex-wrap justify-center gap-1.5 pt-3 text-[11px]">
                <span class="rounded-full border border-[#8a5a1f66] px-2 py-0.5">{{ game.meta?.kind }}</span>
                <span class="rounded-full border border-[#8a5a1f66] px-2 py-0.5">👥 {{ game.meta?.players }}</span>
                <span v-if="game.meta?.adult" class="rounded-full bg-blood px-2 py-0.5 text-parchment">18+</span>
              </div>
            </TarotCard>
            <div class="flex flex-wrap justify-center gap-3">
              <button class="btn-ghost" @click="go">Бросить ещё 🎲</button>
              <NuxtLink :to="`/games/${game.slug}`" class="btn-ghost" @click="close">Подробнее</NuxtLink>
              <NuxtLink to="#booking" class="btn-primary" @click="close">Записаться</NuxtLink>
            </div>
            <button class="text-sm text-ash underline" @click="close">Закрыть</button>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>
