<template>
  <!-- Логотип: золотой череп со свечой на макушке (свой рисунок) -->
  <svg viewBox="0 0 64 64" aria-hidden="true" class="logo-skull">
    <defs>
      <linearGradient id="lsg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#ffe2a8" /><stop offset=".5" stop-color="#f0a040" /><stop offset="1" stop-color="#9a5410" />
      </linearGradient>
    </defs>
    <!-- пламя -->
    <path d="M32 1c4 5 4 8 0 11-4-3-4-6 0-11z" fill="url(#lsg)" class="logo-flame" />
    <rect x="29.5" y="11" width="5" height="5" rx="1" fill="url(#lsg)" />
    <!-- череп -->
    <path d="M32 15c-12 0-20 8-20 19 0 6 3 10 6 12v6c0 2 2 4 4 4h20c2 0 4-2 4-4v-6c3-2 6-6 6-12 0-11-8-19-20-19z" fill="url(#lsg)" />
    <path d="M22 37c0-3 2-5 5-5s5 2 4 5-3 4-5 4-4-1-4-4zm20 0c0-3-2-5-5-5s-5 2-4 5 3 4 5 4 4-1 4-4z" fill="#1a0c05" />
    <path d="M32 41l-3 5h6z" fill="#1a0c05" />
    <path d="M24 51h16M26 50v6M30 50v6M34 50v6M38 50v6" stroke="#1a0c05" stroke-width="1.6" stroke-linecap="round" />
    <path d="M20 26c3-5 7-7 12-7" stroke="#fff6" stroke-width="1.5" fill="none" stroke-linecap="round" />
  </svg>
</template>

<style>
.logo-skull { width: 36px; height: 36px; flex: none; filter: drop-shadow(0 0 6px #f0a04055); }
.logo-flame { transform-origin: 32px 12px; animation: flame 1.8s ease-in-out infinite; }
@keyframes flame { 50% { transform: scale(1.12, .92) rotate(-4deg); } }
@media (prefers-reduced-motion: reduce) { .logo-flame { animation: none; } }
</style>
