<script setup lang="ts">
// Сюжет как карта колоды: рубашка с названием → при наведении (или тапе) переворачивается к описанию
const props = defineProps<{ game: { slug: string; title: string; excerpt: string; cover?: string | null; meta: any } }>()
const flipped = ref(false)
const canHover = ref(false)
onMounted(() => (canHover.value = matchMedia('(hover: hover) and (pointer: fine)').matches))
const m = computed(() => props.game.meta || {})
function onClick(e: MouseEvent) {
  if ((e.target as HTMLElement).closest('a')) return // клик по ссылке — переход
  if (!canHover.value) flipped.value = !flipped.value
}
</script>

<template>
  <div class="story-card" @mouseenter="canHover && (flipped = true)" @mouseleave="canHover && (flipped = false)" @click="onClick" @focusin="flipped = true">
    <TarotCard v-model:flipped="flipped" :interactive="false" variant="dark" :glow="false" width="100%">
      <template #back>
        <div class="absolute inset-x-[7%] bottom-[5%] rounded-xl border border-[#f0a04055] bg-[#130b09ee] px-3 py-2.5 text-center shadow-[0_-6px_18px_#000a]">
          <p class="gold-text line-clamp-2 font-display text-[19px] leading-[1.05]">{{ game.title }}</p>
          <p class="mt-1 text-[10px] uppercase tracking-[.2em] text-[#e9c271]">{{ m.kind }} · 👥 {{ m.players }}</p>
        </div>
        <span v-if="m.adult" class="badge absolute left-5 top-5" style="background: #8a1c1c; color: #f1e6cf">18+</span>
      </template>
      <div class="flex h-full flex-col text-left">
        <span class="badge self-start">{{ m.kind }}</span>
        <p v-if="m.series" class="mt-3 text-[11px] uppercase tracking-widest text-candle">{{ m.series }}</p>
        <h3 class="mt-1 text-2xl text-parchment">{{ game.title }}</h3>
        <p class="mt-2 text-sm text-ash">{{ game.excerpt }}</p>
        <div class="mt-auto flex flex-wrap gap-1.5 pt-3 text-[11px]">
          <span class="rounded border border-wood-2 bg-ink/60 px-2 py-0.5">{{ m.system }}</span>
          <span class="rounded border border-wood-2 bg-ink/60 px-2 py-0.5">👥 {{ m.players }}</span>
          <span v-if="m.level" class="rounded border border-wood-2 bg-ink/60 px-2 py-0.5">ур. {{ m.level }}</span>
          <span v-if="m.adult" class="rounded bg-blood px-2 py-0.5">18+</span>
        </div>
        <div class="mt-3 flex justify-end"><NuxtLink :to="`/games/${game.slug}`" class="btn-primary px-4 py-2 text-sm">Подробнее</NuxtLink></div>
      </div>
    </TarotCard>
  </div>
</template>

<style>
.story-card { cursor: pointer; }
.story-card .tarot-content { padding: 22px 18px 18px; }
</style>
