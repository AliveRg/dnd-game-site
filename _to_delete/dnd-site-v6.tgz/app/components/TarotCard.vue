<script setup lang="ts">
// Карта с двумя сторонами: рубашка (/cards/back.svg) и лицо с инфо/функционалом (слот).
// Переворот — 3D-поворот с лёгким «изгибом» (skew + масштаб + блик), как у настоящей карты.
// v-model:flipped — true = лицом вверх.
const props = withDefaults(
  defineProps<{ flipped?: boolean; interactive?: boolean; variant?: 'paper' | 'gold' | 'dark'; glow?: boolean; width?: string; back?: string; label?: string }>(),
  { flipped: false, interactive: true, variant: 'paper', glow: true, width: '280px', back: '/cards/back.svg', label: 'Перевернуть карту' }
)
const emit = defineEmits<{ 'update:flipped': [boolean] }>()

const anim = ref<'' | 'to-front' | 'to-back'>('')
const shown = ref(props.flipped) // какая сторона «логически» сверху (для блика/эффектов)
watch(
  () => props.flipped,
  (v, old) => {
    if (v === old) return
    anim.value = v ? 'to-front' : 'to-back'
    setTimeout(() => (shown.value = v), 350)
  }
)
function onEnd() {
  anim.value = ''
}
// Позиции искр — фиксированные «случайные»
const sparks = Array.from({ length: 14 }, (_, i) => ({ left: `${8 + ((i * 37) % 84)}%`, top: `${6 + ((i * 53) % 86)}%`, '--i': i }))
function toggle() {
  if (props.interactive) emit('update:flipped', !props.flipped)
}
</script>

<template>
  <div class="tarot" :style="{ '--w': width }">
    <!-- Лучи и искры за картой, когда она открыта -->
    <div v-if="glow && shown" class="tarot-fx" aria-hidden="true">
      <div class="tarot-rays" />
      <span v-for="(sp, i) in sparks" :key="i" class="tarot-spark" :style="sp" />
    </div>

    <div
      class="tarot-inner"
      :class="[{ 'is-front': flipped }, anim]"
      :role="interactive ? 'button' : undefined"
      :tabindex="interactive ? 0 : undefined"
      :aria-label="interactive ? label : undefined"
      :aria-pressed="interactive ? flipped : undefined"
      @click="toggle"
      @keydown.enter.prevent="toggle"
      @keydown.space.prevent="toggle"
      @animationend.self="onEnd"
    >
      <div class="tarot-face tarot-back">
        <img :src="back" alt="" draggable="false" />
        <slot name="back" />
      </div>
      <div class="tarot-face tarot-front" :class="`v-${variant}`">
        <div class="tarot-frame">
          <span class="st st-tl">✦</span><span class="st st-tr">✦</span><span class="st st-bl">✦</span><span class="st st-br">✦</span>
          <div class="tarot-content"><slot /></div>
        </div>
      </div>
      <div class="tarot-sheen" aria-hidden="true" />
    </div>
  </div>
</template>

<style>
.tarot { position: relative; width: var(--w); max-width: 100%; aspect-ratio: 5 / 7; perspective: 1400px; }
.tarot-inner { position: relative; width: 100%; height: 100%; transform-style: preserve-3d; transition: transform .2s; cursor: default; }
.tarot-inner[role='button'] { cursor: pointer; }
.tarot-inner[role='button']:focus-visible { outline: 2px solid #f0a040; outline-offset: 6px; border-radius: 22px; }
.tarot-inner.is-front { transform: rotateY(180deg); }
.tarot-inner[role='button']:not(.to-front):not(.to-back):hover { transform: translateY(-4px) rotateZ(-1deg); }
.tarot-inner.is-front[role='button']:not(.to-front):not(.to-back):hover { transform: rotateY(180deg) translateY(-4px) rotateZ(1deg); }

/* Переворот с изгибом: карта приподнимается, «гнётся» (skew/scale) на ребре и ложится обратно */
.tarot-inner.to-front { animation: tarot-flip .9s cubic-bezier(.45, .05, .25, 1) forwards; }
.tarot-inner.to-back { animation: tarot-flip .9s cubic-bezier(.45, .05, .25, 1) reverse forwards; }
@keyframes tarot-flip {
  0%   { transform: rotateY(0) translateZ(0); }
  22%  { transform: translateY(-14px) rotateY(40deg) skewY(-3deg) scale(1.04); }
  50%  { transform: translateY(-22px) rotateY(90deg) skewY(-7deg) scale(1.08, 1.02); }
  78%  { transform: translateY(-10px) rotateY(145deg) skewY(3deg) scale(1.04); }
  100% { transform: rotateY(180deg); }
}
/* Тень-«кривизна» на гранях во время переворота */
.tarot-inner.to-front .tarot-face::after, .tarot-inner.to-back .tarot-face::after { animation: tarot-bend .9s ease-in-out; }
.tarot-face::after { content: ''; position: absolute; inset: 0; border-radius: inherit; pointer-events: none; opacity: 0;
  background: linear-gradient(90deg, #0000 0%, #0000 35%, #0007 100%); }
@keyframes tarot-bend { 0%, 100% { opacity: 0; } 50% { opacity: 1; } }

.tarot-face { position: absolute; inset: 0; border-radius: 22px; overflow: hidden; backface-visibility: hidden; -webkit-backface-visibility: hidden;
  box-shadow: 0 18px 40px #000c, 0 0 0 1px #0008; }
.tarot-back img { width: 100%; height: 100%; display: block; object-fit: cover; user-select: none; }
.tarot-front { transform: rotateY(180deg); }

/* Лицевые стороны */
.tarot-front.v-paper { background: linear-gradient(180deg, #fff2 0, #0000 30%, #0002), url('/textures/paper.webp'); background-size: auto, 400px; color: #2b1d10; }
.tarot-front.v-dark { background: linear-gradient(180deg, #1b120ce6, #0d0806f2), url('/textures/wood.webp'); background-size: auto, 400px; color: #efe3c8; }
.tarot-front.v-gold { background: radial-gradient(120% 80% at 30% 10%, #fff5, #0000 50%), linear-gradient(180deg, #0000, #0003), url('/textures/gold.webp') center / cover; color: #2a1203; }
.tarot-frame { position: absolute; inset: 12px; border-radius: 30px 30px 30px 30px / 40px; border: 2px solid currentColor; opacity: 1; display: flex; }
.v-paper .tarot-frame { border-color: #8a5a1f; box-shadow: inset 0 0 0 4px #e9dcc0, inset 0 0 0 5px #8a5a1f66; }
.v-dark .tarot-frame { border-color: #c8913c; box-shadow: inset 0 0 0 4px #1d1611, inset 0 0 0 5px #c8913c55; }
.v-gold .tarot-frame { border-color: #5a3a15; box-shadow: inset 0 0 0 4px #e9c27188, inset 0 0 0 5px #5a3a1588; border-style: double; border-width: 4px; }
.tarot-frame .st { position: absolute; font-size: 14px; line-height: 1; color: #c8913c; }
.v-gold .tarot-frame .st { color: #5a3a15; }
.st-tl { top: 8px; left: 10px; } .st-tr { top: 8px; right: 10px; } .st-bl { bottom: 8px; left: 10px; } .st-br { bottom: 8px; right: 10px; }
.tarot-content { position: relative; flex: 1; display: flex; flex-direction: column; padding: 26px 20px 20px; text-align: center; overflow: hidden; }

/* Блик, пробегающий по карте при перевороте */
.tarot-sheen { position: absolute; inset: 0; border-radius: 22px; pointer-events: none; transform: translateZ(1px);
  background: linear-gradient(115deg, #0000 30%, #fff5 48%, #0000 62%); background-size: 260% 100%; background-position: 120% 0; opacity: 0; }
.to-front .tarot-sheen, .to-back .tarot-sheen { animation: tarot-sheen .9s ease-out; }
@keyframes tarot-sheen { 0% { opacity: 0; background-position: 120% 0; } 40% { opacity: 1; } 100% { opacity: 0; background-position: -60% 0; } }

/* Лучи и искры (как на референсах) */
.tarot-fx { position: absolute; inset: -45%; pointer-events: none; z-index: -1; }
.tarot-rays { position: absolute; inset: 0; border-radius: 50%;
  background: repeating-conic-gradient(from 0deg, #f6d58a55 0deg 4deg, #0000 4deg 15deg);
  -webkit-mask: radial-gradient(circle, #000 15%, #0000 68%); mask: radial-gradient(circle, #000 15%, #0000 68%);
  animation: tarot-rays 28s linear infinite, tarot-in .8s ease-out; }
@keyframes tarot-rays { to { transform: rotate(360deg); } }
@keyframes tarot-in { from { opacity: 0; transform: scale(.6); } }
.tarot-spark { position: absolute; width: 12px; height: 12px;
  background: #fff6d0; clip-path: polygon(50% 0, 62% 38%, 100% 50%, 62% 62%, 50% 100%, 38% 62%, 0 50%, 38% 38%);
  animation: tarot-twinkle calc(1.4s + var(--i) * .17s) ease-in-out infinite; animation-delay: calc(var(--i) * -.23s); filter: drop-shadow(0 0 4px #f6d58a); }
@keyframes tarot-twinkle { 0%, 100% { opacity: .1; transform: scale(.4) rotate(0); } 50% { opacity: 1; transform: scale(1) rotate(45deg); } }

@media (prefers-reduced-motion: reduce) {
  .tarot-inner.to-front, .tarot-inner.to-back { animation-duration: .01s; }
  .tarot-rays, .tarot-spark { animation: none; }
}
</style>
