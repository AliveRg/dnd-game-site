<script setup lang="ts">
import { LANDINGS, ARTICLES, pagePath, fillCity } from '#shared/seo-pages'
const cfg = useRuntimeConfig().public
const route = useRoute()
const open = ref(false)
// Меню из 4 пунктов: объединённые страницы
const nav = [
  { to: '/', label: 'Главная' },
  { to: '/klub', label: 'Клуб и статьи' },
  { to: '/games', label: 'Сюжеты и карта' },
  { to: '/raspisanie', label: 'Расписание и цены' }
]
const short = (s: string) => fillCity(s, cfg.cityIn, cfg.city).replace(/:.*$/, '')
// Блок записи внизу каждой страницы (кроме тех, где он не нужен)
const showBooking = computed(() => !route.path.startsWith('/dragons'))

useHead({
  meta: String(cfg.indexable) === 'true' ? [] : [{ name: 'robots', content: 'noindex, nofollow' }],
  titleTemplate: (t) => (t ? `${t}` : `${cfg.siteName} — клуб настольных ролевых игр D&D`),
  script: [
    {
      type: 'application/ld+json',
      innerHTML: JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'EntertainmentBusiness',
        name: cfg.siteName,
        url: cfg.siteUrl,
        image: `${cfg.siteUrl}/images/og.jpg`,
        description: 'Клуб настольных ролевых игр: D&D 5e, ваншоты и кампании, до 5 игроков за столом.',
        priceRange: '1500–3000 ₽',
        address: { '@type': 'PostalAddress', addressLocality: cfg.city, addressCountry: 'RU' }
      })
    }
  ]
})
</script>

<template>
  <div class="flex min-h-dvh flex-col">
    <header class="fixed inset-x-0 top-0 z-40 shadow-[0_6px_20px_#000a]" style="background: linear-gradient(180deg,#170d0be6,#130b09f2), url(/textures/wood.webp) center / 520px">
      <div class="container-x flex h-16 items-center justify-between gap-4">
        <NuxtLink to="/" class="flex items-center gap-2.5" aria-label="На главную">
          <LogoSkull />
          <span class="gold-text font-display text-xl leading-none">{{ cfg.siteName }}</span>
        </NuxtLink>
        <nav class="hidden items-center gap-2 lg:flex" aria-label="Основное меню">
          <NuxtLink v-for="n in nav" :key="n.to" :to="n.to" class="nav-pill">{{ n.label }}</NuxtLink>
        </nav>
        <NuxtLink to="#booking" class="btn-primary hidden py-2 lg:inline-flex">Записаться</NuxtLink>
        <button class="nav-pill lg:hidden" :aria-expanded="open" aria-label="Меню" @click="open = !open">☰</button>
      </div>
      <div class="metal-band" />
      <nav v-if="open" class="container-x grid gap-2 bg-ink py-4 lg:hidden" @click="open = false">
        <NuxtLink v-for="n in nav" :key="n.to" :to="n.to" class="nav-pill py-2.5">{{ n.label }}</NuxtLink>
        <div class="flex justify-end"><NuxtLink to="#booking" class="btn-primary">Записаться</NuxtLink></div>
      </nav>
    </header>

    <main class="flex-1 pt-[72px]">
      <slot />
      <BookingSection v-if="showBooking" />
    </main>

    <div class="metal-band" />
    <footer class="relative overflow-hidden py-8 text-sm text-ash" style="background: linear-gradient(180deg,#170d0bf0,#130b09f7), url(/textures/wood.webp) center / 520px">
      <img src="/decor/nails.webp" alt="" class="decor -bottom-4 right-4 hidden w-28 rotate-12 opacity-80 md:block" loading="lazy" />
      <div class="container-x mb-6 grid gap-6 sm:grid-cols-3">
        <div>
          <p class="mb-2 font-semibold text-parchment">Играть</p>
          <NuxtLink v-for="p in LANDINGS" :key="p.slug" :to="pagePath(p)" class="block py-0.5 hover:text-candle">{{ short(p.h1) }}</NuxtLink>
        </div>
        <div>
          <p class="mb-2 font-semibold text-parchment">Статьи</p>
          <NuxtLink v-for="p in ARTICLES" :key="p.slug" :to="pagePath(p)" class="block py-0.5 hover:text-candle">{{ short(p.h1) }}</NuxtLink>
        </div>
        <div>
          <p class="mb-2 font-semibold text-parchment">Клуб</p>
          <NuxtLink v-for="n in nav" :key="n.to" :to="n.to" class="block py-0.5 hover:text-candle">{{ n.label }}</NuxtLink>
          <NuxtLink to="/generator-geroya" class="block py-0.5 hover:text-candle">Генератор героя</NuxtLink>
          <NuxtLink to="/kontakty" class="block py-0.5 hover:text-candle">Контакты</NuxtLink>
        </div>
      </div>
      <div class="container-x flex flex-col justify-between gap-4 md:flex-row">
        <p>© {{ new Date().getFullYear() }} {{ cfg.siteName }}. Клуб настольных ролевых игр.</p>
        <NuxtLink to="/privacy" class="hover:text-candle">Политика конфиденциальности</NuxtLink>
      </div>
    </footer>
  </div>
</template>
