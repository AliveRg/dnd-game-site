<script setup lang="ts">
// Согласие на обработку ПД: галочку нельзя поставить «молча» — сначала окно с текстом согласия, потом кнопка «Согласен»
const model = defineModel<boolean>({ default: false })
const props = defineProps<{ field?: string }>()
const open = ref(false)
function onClick(e: Event) {
  e.preventDefault()
  if (model.value) model.value = false
  else open.value = true
}
function accept() { model.value = true; open.value = false }
onMounted(() => window.addEventListener('keydown', (e) => e.key === 'Escape' && (open.value = false)))
</script>

<template>
  <div>
    <label class="flex cursor-pointer items-start gap-2 text-xs text-ash" @click="onClick">
      <input :checked="model" :data-field="props.field" type="checkbox" class="mt-0.5" tabindex="0" @keydown.space.prevent="onClick" />
      <span>Согласен на обработку персональных данных и с политикой конфиденциальности <span class="text-candle underline">(прочитать)</span></span>
    </label>

    <Teleport to="body">
      <Transition enter-active-class="transition duration-200" enter-from-class="opacity-0" leave-active-class="transition duration-150" leave-to-class="opacity-0">
        <div v-if="open" class="fixed inset-0 z-[60] grid place-items-center bg-ink/85 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Согласие на обработку персональных данных" @click.self="open = false">
          <div class="card max-h-[85vh] w-full max-w-lg overflow-y-auto">
            <div class="mb-3 flex items-center gap-3">
              <img src="/decor/scroll.webp" alt="" class="h-12 w-12 object-contain" />
              <h3 class="text-3xl">Согласие на обработку данных</h3>
            </div>
            <div class="space-y-2 text-sm text-ash">
              <p>Отправляя заявку, я даю согласие клубу «{{ useRuntimeConfig().public.siteName }}» на обработку моих персональных данных: имени и контакта для связи (Telegram, VK или e-mail).</p>
              <p>Цель — связаться со мной по поводу записи на игру. Данные не передаются третьим лицам и хранятся не дольше, чем нужно для этой цели.</p>
              <p>Согласие можно отозвать в любой момент, написав нам. Подробнее — в <NuxtLink to="/privacy" class="text-candle underline" @click="open = false">политике конфиденциальности</NuxtLink>.</p>
              <!-- TODO: финальный юридический текст + реквизиты оператора от заказчика -->
            </div>
            <div class="mt-5 flex justify-end gap-3">
              <button type="button" class="btn-ghost" @click="open = false">Отмена</button>
              <button type="button" class="btn-primary" @click="accept">Согласен</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>
