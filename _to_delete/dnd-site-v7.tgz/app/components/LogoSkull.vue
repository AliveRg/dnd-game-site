<template>
  <!-- Логотип: реалистичный череп (из набора декора), с тёплым свечением -->
  <img src="/images/logo-skull.webp" alt="" width="40" height="36" class="logo-skull" decoding="async" />
</template>

<style>
.logo-skull { width: 40px; height: auto; flex: none; filter: drop-shadow(0 0 6px #f0802a55) drop-shadow(0 2px 2px #000); }
</style>
