<script setup lang="ts">
import { gameIcon } from '#shared/game-icons'
defineProps<{ slug?: string | null; size?: number }>()
</script>

<template>
  <svg :width="size || 48" :height="size || 48" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path :d="gameIcon(slug)" />
  </svg>
</template>
