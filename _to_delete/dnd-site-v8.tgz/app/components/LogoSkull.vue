<script setup lang="ts">
// Векторный логотип-череп (без свечи). Источник путей — shared/skull.ts
import { SKULL } from '#shared/skull'
const id = useId()
</script>

<template>
  <svg viewBox="0 0 64 64" aria-hidden="true" class="logo-skull">
    <defs>
      <linearGradient :id="`${id}g`" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#ffe6b0" /><stop offset=".45" stop-color="#f0a040" /><stop offset="1" stop-color="#8f4c0d" />
      </linearGradient>
    </defs>
    <path :d="SKULL.base" :fill="`url(#${id}g)`" />
    <path :d="SKULL.shade" fill="#5a2a06" opacity=".55" />
    <path :d="SKULL.brow" stroke="#5a2a06" stroke-width="1.4" stroke-linecap="round" fill="none" opacity=".7" />
    <path :d="SKULL.eyes" fill="#1a0c05" />
    <path :d="SKULL.nose" fill="#1a0c05" />
    <path :d="SKULL.teeth" stroke="#1a0c05" stroke-width="1.5" stroke-linecap="round" fill="none" />
    <path :d="SKULL.crack" stroke="#5a2a06" stroke-width="1" stroke-linecap="round" fill="none" />
    <path :d="SKULL.shine" stroke="#fff8" stroke-width="1.6" stroke-linecap="round" fill="none" />
  </svg>
</template>

<style>
.logo-skull { width: 34px; height: 34px; flex: none; filter: drop-shadow(0 0 6px #f0802a55) drop-shadow(0 1px 1px #000); }
</style>
