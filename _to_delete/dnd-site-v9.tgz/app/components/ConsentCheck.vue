<script setup lang="ts">
// Согласие на обработку ПД.
// Первое нажатие на галочку открывает окно «Прочитайте согласие» → «Согласен» ставит галочку.
// После прочтения галочку можно свободно снимать/ставить. Кнопка «Отправить» без согласия тоже открывает окно.
const model = defineModel<boolean>({ default: false })
const props = defineProps<{ field?: string }>()
const open = ref(false)
const read = ref(false)
function toggle() {
  if (model.value) { model.value = false; return }
  if (read.value) model.value = true
  else open.value = true
}
function accept() { read.value = true; model.value = true; open.value = false }
function show() { open.value = true }
defineExpose({ show })
const onKey = (e: KeyboardEvent) => e.key === 'Escape' && (open.value = false)
onMounted(() => window.addEventListener('keydown', onKey))
onBeforeUnmount(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div>
    <div class="flex items-start gap-2 text-xs text-ash">
      <button type="button" role="checkbox" :aria-checked="model" :data-field="props.field" class="consent-box" :class="model && 'on'" aria-label="Согласие на обработку персональных данных" @click="toggle" />
      <span>Согласен на обработку персональных данных и с политикой конфиденциальности —
        <button type="button" class="text-candle underline" @click="show">прочитать</button></span>
    </div>

    <Teleport to="body">
      <Transition enter-active-class="transition duration-200" enter-from-class="opacity-0" leave-active-class="transition duration-150" leave-to-class="opacity-0">
        <div v-if="open" class="fixed inset-0 z-[60] grid place-items-center bg-ink/85 p-4" role="dialog" aria-modal="true" aria-label="Согласие на обработку персональных данных" @click.self="open = false">
          <div class="card max-h-[85vh] w-full max-w-lg overflow-y-auto">
            <div class="mb-3 flex items-center gap-3">
              <img src="/decor/scroll.webp" alt="" class="h-12 w-12 object-contain" />
              <h3 class="text-3xl">Прочитайте согласие</h3>
            </div>
            <div class="space-y-2 text-sm text-ash">
              <p>Отправляя заявку, я даю согласие клубу «{{ useRuntimeConfig().public.siteName }}» на обработку моих персональных данных: имени и контакта для связи (Telegram, VK или e-mail).</p>
              <p>Цель — связаться со мной по поводу записи на игру. Данные не передаются третьим лицам и хранятся не дольше, чем нужно для этой цели.</p>
              <p>Согласие можно отозвать в любой момент, написав нам. Подробнее — в <NuxtLink to="/privacy" class="text-candle underline" @click="open = false">политике конфиденциальности</NuxtLink>.</p>
              <!-- TODO: финальный юридический текст + реквизиты оператора от заказчика -->
            </div>
            <div class="mt-5 flex justify-end gap-3">
              <button type="button" class="btn-ghost" @click="open = false">Закрыть</button>
              <button type="button" class="btn-primary" @click="accept">Согласен</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<style>
.consent-box { flex: none; width: 18px; height: 18px; margin-top: 1px; border-radius: 4px; border: 1px solid #8a5a1f; background: #130b09; display: grid; place-content: center; cursor: pointer; }
.consent-box.on { background: var(--gold); border-color: #ffc670; }
.consent-box.on::after { content: ''; width: 9px; height: 5px; border: 2px solid #2a1203; border-top: 0; border-right: 0; transform: rotate(-45deg) translate(1px, -1px); }
.consent-box:focus-visible { outline: 2px solid #f0a040; outline-offset: 2px; }
</style>
