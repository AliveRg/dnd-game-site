<script setup lang="ts">
import { TARIFFS, FRIEND_DISCOUNT, FRIEND_DISCOUNT_CAP, PROMO_UNTIL, REGULAR_PRICE_4H } from '#shared/utils/pricing'
const until = new Date(PROMO_UNTIL).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })
</script>

<template>
  <div>
    <div class="grid gap-6 md:grid-cols-3">
      <div v-for="t in TARIFFS" :key="t.id" class="card relative flex flex-col" :class="t.id === 'promo4' && '!border-candle/70'">
        <span v-if="'badge' in t" class="badge mb-3 self-start">{{ t.badge }}</span>
        <span v-else class="mb-3 h-6" aria-hidden="true" />
        <h3 class="text-3xl">{{ t.title }}</h3>
        <p class="gold-text mt-4 text-5xl font-bold">{{ t.price.toLocaleString('ru-RU') }} ₽</p>
        <p class="text-sm text-ash">с человека за {{ t.hours }} {{ t.hours === 6 ? 'часов' : 'часа' }} игры</p>
        <p v-if="t.id === 'promo4'" class="mt-1 text-xs text-candle">Акция до {{ until }}, далее {{ REGULAR_PRICE_4H }} ₽</p>
        <p class="mt-4 flex-1 text-sm">{{ t.note }}</p>
        <div class="mt-6 flex justify-end"><NuxtLink to="#booking" class="btn-ghost">Выбрать</NuxtLink></div>
      </div>
    </div>
    <p class="mt-6 text-ash">
      Приведи друга — <b class="text-candle">−{{ FRIEND_DISCOUNT }} ₽</b> тебе за каждого на 4-часовую партию (скидка до {{ FRIEND_DISCOUNT_CAP * 100 }}%), а друг играет за 1 500 ₽.
    </p>
  </div>
</template>
