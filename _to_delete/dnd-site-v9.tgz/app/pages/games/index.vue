<script setup lang="ts">
// Объединённая страница: Сюжеты + Карта миров
const cfg = useRuntimeConfig().public
const city = cfg.cityIn ? ` ${cfg.cityIn}` : ''
useSiteSeo({
  title: `Сюжеты и карта миров — ваншоты D&D 5e и НРИ${city}`,
  description: 'Все истории клуба на карте миров: ваншоты, модули и кампании по D&D 5e, Витрувию и другим НРИ. Выбирайте жанр и записывайтесь.'
})
const { data: games } = await useFetch('/api/games', { default: () => [] as any[] })
const filter = ref<'all' | 'Ваншот' | 'Модуль' | 'Кампания'>('all')
const list = computed(() => (filter.value === 'all' ? games.value : games.value.filter((g: any) => g.meta?.kind === filter.value)))
</script>

<template>
  <div>
    <section id="karta" class="section">
      <div class="container-x">
        <SectionTitle icon="key" as="h1">Сюжеты и карта миров</SectionTitle>
        <p class="-mt-3 mb-6 text-ash">Каждая точка — отдельная история. Нажмите на метку или название в списке.</p>
        <WorldMapSection />
      </div>
    </section>

    <section id="syuzhety" class="section">
      <div class="container-x">
        <SectionTitle icon="book">Колода историй</SectionTitle>
        <div class="mb-6 flex flex-wrap gap-2">
          <button v-for="f in ['all', 'Ваншот', 'Модуль', 'Кампания']" :key="f" class="nav-pill" :class="filter === f && 'router-link-exact-active'" @click="filter = f as any">
            {{ f === 'all' ? 'Все' : f }}
          </button>
        </div>
        <div class="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          <StoryCard v-for="g in list" :key="g.slug" :game="g" />
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container-x">
        <HeroTeaser />
      </div>
    </section>
  </div>
</template>
