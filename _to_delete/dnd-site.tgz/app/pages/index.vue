<script setup lang="ts">
const cfg = useRuntimeConfig().public
const city = cfg.cityIn ? ` ${cfg.cityIn}` : ''

useSiteSeo({
  title: `Клуб D&D и НРИ${city} — партия 4 часа за 2000 ₽`,
  description: `Играйте в Dungeons & Dragons 5e и другие НРИ${city}: опытный мастер, до 5 игроков, новый сюжет каждую неделю. Партия 4 часа — 2000 ₽ по акции. Запись онлайн.`
})

const { data: games } = await useFetch('/api/games', { default: () => [] as any[] })

const features = [
  { icon: '🎲', title: 'Новая история каждую неделю', text: 'Каждую неделю открываем запись на новый сюжет в новом сеттинге — от сказки до хоррора.' },
  { icon: '🕯️', title: 'Атмосфера за столом', text: 'Карты, миниатюры, свечи и музыка. Приходите и просто играйте — всё уже готово.' },
  { icon: '🧭', title: 'Новичкам — можно', text: 'Объясним правила за 10 минут, поможем собрать персонажа. Опыт не нужен.' },
  { icon: '👥', title: 'До 5 игроков', text: 'Маленькие столы — каждому игроку хватает внимания мастера и времени на отыгрыш.' }
]

const faq = [
  { q: 'Я никогда не играл в D&D. Можно прийти?', a: 'Да. Мастер объяснит правила, поможет с персонажем. Для первой игры советуем сказочные ваншоты низкого уровня.' },
  { q: 'Сколько длится партия?', a: 'Стандартная партия — 4 часа, длинная — 6 часов. Кампании идут несколько встреч.' },
  { q: 'Сколько стоит?', a: 'По акции 2000 ₽ за 4 часа, 3000 ₽ за 6 часов. Если вас пригласил игрок клуба — 1500 ₽, а пригласившему −500 ₽ за каждого друга.' },
  { q: 'Сколько человек за столом?', a: 'До 5 игроков на партию. Есть отдельные истории на двоих.' },
  { q: 'Нужно ли что-то приносить?', a: 'Нет: кубики, листы персонажей, карты и миниатюры есть в клубе. Свои кубики — приветствуются.' }
]

useHead({
  script: [{
    type: 'application/ld+json',
    innerHTML: JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: faq.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } }))
    })
  }]
})
</script>

<template>
  <div>
    <!-- 1. HERO: оффер + цена по акции + форма -->
    <section class="relative flex min-h-[calc(100dvh-4rem)] items-center overflow-hidden">
      <HeroSlides />
      <div class="container-x relative grid items-center gap-10 py-16 lg:grid-cols-[1.2fr_1fr]">
        <div>
          <p class="mb-4 inline-block rounded-full border border-candle/50 px-4 py-1 text-sm text-candle">Акция: партия 4 часа — 2 000 ₽</p>
          <h1 class="text-4xl leading-tight md:text-6xl">Клуб настольных ролевых игр D&amp;D{{ city }}</h1>
          <p class="mt-6 max-w-xl text-lg text-parchment/85">
            Уникальные сюжеты и миры, живой мастер и до 5 игроков за столом. Каждую неделю — новая история в новом сеттинге.
          </p>
          <div class="mt-8 flex flex-wrap gap-3">
            <NuxtLink to="/#booking" class="btn-primary">Выбрать дату</NuxtLink>
            <NuxtLink to="/games" class="btn-ghost">Смотреть сюжеты</NuxtLink>
          </div>
        </div>
        <QuickForm />
      </div>
    </section>

    <!-- 2. О КЛУБЕ -->
    <section id="about" class="section">
      <div class="container-x">
        <h2 class="section-title">О клубе</h2>
        <p class="mb-10 max-w-3xl text-lg text-ash">
          Хижина Всякой Всячины — место, где собираются за одним столом, чтобы вместе рассказать историю.
          Играем в Dungeons &amp; Dragons 5e (редакция 2024), Витрувий, «Десять свечей», «Смерть в стиле Диско» и другие системы.
          <!-- TODO: текст про мастера/клуб от заказчика -->
        </p>
        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <div v-for="f in features" :key="f.title" class="card">
            <p class="text-3xl">{{ f.icon }}</p>
            <h3 class="mt-3 text-xl">{{ f.title }}</h3>
            <p class="mt-2 text-sm text-ash">{{ f.text }}</p>
          </div>
        </div>
      </div>
    </section>

    <!-- 3. СЮЖЕТЫ И МИРЫ -->
    <section class="section bg-wood/40">
      <div class="container-x">
        <div class="mb-8 flex items-end justify-between gap-4">
          <h2 class="section-title mb-0">Уникальные сюжеты и миры</h2>
          <NuxtLink to="/games" class="hidden text-candle hover:underline md:block">Все сюжеты →</NuxtLink>
        </div>
        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <GameCard v-for="g in games.slice(0, 6)" :key="g.slug" :game="g" />
        </div>
        <NuxtLink to="/games" class="btn-ghost mt-8 md:hidden">Все сюжеты</NuxtLink>
      </div>
    </section>

    <!-- 4. ЦЕНЫ -->
    <section id="prices" class="section">
      <div class="container-x">
        <h2 class="section-title">Цены</h2>
        <PricingCards />
      </div>
    </section>

    <!-- 5. КАЛЕНДАРЬ + ЗАЯВКА -->
    <section id="booking" class="section bg-wood/40">
      <div class="container-x">
        <h2 class="section-title">Запись на игру</h2>
        <p class="-mt-4 mb-8 text-ash">До 5 человек на партию. Выберите день в календаре или оставьте заявку без даты.</p>
        <BookingCalendar />
      </div>
    </section>

    <!-- 6. FAQ -->
    <section class="section">
      <div class="container-x max-w-3xl">
        <h2 class="section-title">Частые вопросы</h2>
        <details v-for="f in faq" :key="f.q" class="border-b border-wood-2 py-4">
          <summary class="cursor-pointer text-lg">{{ f.q }}</summary>
          <p class="mt-2 text-ash">{{ f.a }}</p>
        </details>
      </div>
    </section>
  </div>
</template>
