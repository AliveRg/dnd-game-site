import tailwindcss from '@tailwindcss/vite'

// Все переменные ниже переопределяются через окружение: NUXT_<KEY>
// Пример: runtimeConfig.smtpHost  <-  NUXT_SMTP_HOST
//         runtimeConfig.public.siteUrl  <-  NUXT_PUBLIC_SITE_URL
export default defineNuxtConfig({
  compatibilityDate: '2026-11-01',
  devtools: { enabled: false },

  css: ['~/assets/css/main.css'],
  vite: { plugins: [tailwindcss()] },

  runtimeConfig: {
    // БД (Timeweb PostgreSQL)
    databaseUrl: '',
    dbSsl: 'false',

    // Почта
    smtpHost: '',
    smtpPort: '465',
    smtpUser: '',
    smtpPass: '',
    mailFrom: '',
    mailTo: '',

    // S3 (Timeweb Object Storage)
    s3Endpoint: 'https://s3.twcstorage.ru',
    s3Region: 'ru-1',
    s3Bucket: '',
    s3AccessKey: '',
    s3SecretKey: '',

    // Админка /dragons
    adminLogin: '',
    adminPassword: '',
    sessionPassword: '',

    public: {
      siteUrl: 'http://localhost:3000',
      siteName: 'Хижина Всякой Всячины',
      // Город в предложном падеже для SEO-заголовков, напр. 'в Санкт-Петербурге'. Пусто = без города
      cityIn: '',
      yandexMetrikaId: ''
    }
  },

  app: {
    head: {
      htmlAttrs: { lang: 'ru' },
      charset: 'utf-8',
      viewport: 'width=device-width, initial-scale=1',
      link: [
        { rel: 'icon', type: 'image/svg+xml', href: '/favicon.svg' }
        // Шрифты: кладём woff2 в public/fonts и подключаем в main.css (Google Fonts из РФ грузится нестабильно)
      ],
      meta: [{ name: 'theme-color', content: '#120d0a' }]
    }
  },

  routeRules: {
    '/dragons/**': { ssr: false, headers: { 'X-Robots-Tag': 'noindex, nofollow' } },
    '/api/admin/**': { headers: { 'X-Robots-Tag': 'noindex' } },
    '/images/**': { headers: { 'Cache-Control': 'public, max-age=31536000, immutable' } },
    '/media/**': { headers: { 'Cache-Control': 'public, max-age=2592000' } }
  },

  nitro: {
    compressPublicAssets: true
  }
})
