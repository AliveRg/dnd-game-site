// Тарифы из ТЗ. Меняешь цены — только здесь (используется и на фронте, и в письме).
export const TARIFFS = [
  { id: 'promo4', title: 'Партия 4 часа', hours: 4, price: 2000, badge: 'Акция', note: 'Основной формат' },
  { id: 'long6', title: 'Длинная партия 6 часов', hours: 6, price: 3000, note: 'Для тех, кто не может остановиться' },
  { id: 'invited4', title: 'По приглашению, 4 часа', hours: 4, price: 1500, note: 'Если вас позвал игрок клуба' }
] as const

export type TariffId = (typeof TARIFFS)[number]['id']

export const FRIEND_DISCOUNT = 500 // скидка пригласившему за каждого друга (только 4-часовые партии)
export const MAX_PLAYERS = 5

/**
 * Оценка стоимости для заявки.
 * players — сколько мест бронирует человек (он + друзья, которых он приводит).
 * Друзья идут по тарифу "по приглашению", а пригласившему -500 ₽ за каждого (не ниже 0).
 * ⚠ Правило уточнить у заказчика (есть ли потолок скидки).
 */
export function estimatePrice(tariffId: string, players: number) {
  const t = TARIFFS.find((x) => x.id === tariffId) ?? TARIFFS[0]
  const friends = Math.max(0, Math.min(players, MAX_PLAYERS) - 1)
  if (t.id === 'long6') return { total: t.price * (friends + 1), perHost: t.price, friends, discount: 0 }
  if (t.id === 'invited4') return { total: t.price * (friends + 1), perHost: t.price, friends, discount: 0 }
  const discount = Math.min(t.price, friends * FRIEND_DISCOUNT)
  const invited = TARIFFS.find((x) => x.id === 'invited4')!.price
  return { total: t.price - discount + friends * invited, perHost: t.price - discount, friends, discount }
}
